// Fichier Evenement1.h

void Tache1 (void);
