// Fichier Evenement2.h

void Tache2 (void);
