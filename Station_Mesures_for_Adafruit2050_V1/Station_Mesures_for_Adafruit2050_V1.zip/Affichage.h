// Fichier Affichage.h
// Routines d'affichage :
//  Sur le terminal série

#include <Arduino.h>

// Définition de constantes symboliques

// Fonctions prototypes
