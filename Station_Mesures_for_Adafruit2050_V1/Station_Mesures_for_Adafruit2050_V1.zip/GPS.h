// Fichier GPS.h

// Définition des types de données pour gestion des données GPS


// Définition de constantes symboliques


// Fonctions prototypes
